import './ContentRight.css';

const ContentRight = ({ children }) => {
  return <div className='ContentRight'>{children}</div>;
};

export default ContentRight;
