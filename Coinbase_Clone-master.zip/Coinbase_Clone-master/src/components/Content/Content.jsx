import './Content.css';

const Content = ({ children }) => {
  return <div className='Content'>{children}</div>;
};

export default Content;
