import './ContentCenter.css';

const ContentCenter = ({ children }) => {
  return <div className='ContentCenter'>{children}</div>;
};

export default ContentCenter;
