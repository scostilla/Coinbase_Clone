import './TabContent.css';

const TabContent = ({ children }) => {
  return <div className='TabContent'>{children}</div>;
};

export default TabContent;
