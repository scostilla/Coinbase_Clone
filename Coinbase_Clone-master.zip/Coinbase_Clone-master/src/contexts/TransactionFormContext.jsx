import { createContext } from 'react';

const TransactionFormContext = createContext();

export { TransactionFormContext };
