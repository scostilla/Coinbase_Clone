export const findAsset = (id, assets) =>
  assets.find((asset) => asset.id === id);
